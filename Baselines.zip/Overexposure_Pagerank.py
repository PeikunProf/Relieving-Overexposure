# -*- coding: utf-8 -*-
"""
@author: PeiKun

"""

from Multi_Diffusion_procedure import Triggered_Procedure
import networkx
import time
import copy 


def writeTxt(dataList, fileName):  
    f = open(fileName, 'a')
    f.write(str(dataList))
    f.write('\n')

    
# main function    
if __name__ == '__main__':
    start = time.perf_counter()
    #import links with influence probability and similarity
    f = open("Delicious_Pro_Sim.txt") 
    #f = open("Douban_Pro_Sim.txt") 
    #f = open("Gnutella_Pro_Sim.txt")
    #f = open("Gemsec_Pro_Sim.txt")     
    
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1], weight = float(split_row[2]), Similarity = float(split_row[3]))
    
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    print("The number of nodes", G.number_of_nodes())
    
    
    PR = networkx.pagerank(DG, alpha=0.85)
    Nodes_Value_PR = {}
    for node, value in PR.items():
        Nodes_Value_PR[node] = value
    PR_value_descend = dict(sorted(Nodes_Value_PR.items(), key=lambda x:x[1], reverse=True)) 
    
    Candidate_Indivi = list(PR_value_descend.keys())

    Per = [0.5,0.25,0.125,0.125]
    c = 0.01           # Parameter, Has been determined
    k = 4              # Triggered stage
    b_set = [40,80,120,160,200,240,280,320]
    
    for b in b_set:
        Seed_set = []
        Candidate_Set = copy.deepcopy(Candidate_Indivi)
        for i in range(k):
            Lay_i_Seed = []
        
            B_new = int(b*Per[i])     
            while len(Lay_i_Seed) < B_new and len(Candidate_Set) > 0:
                Med_Seed_set = copy.deepcopy(Seed_set)
                Med_Candidate = copy.deepcopy(Lay_i_Seed)
                Med_Candidate.append(Candidate_Set[0])
                Med_Seed_set.append(Med_Candidate)
                del Med_Candidate
                
                Sum_P = 0
                Sum_N = 0
                for j in range(400):
                    Lay_Candidaite_set = copy.deepcopy(Med_Seed_set)
                    Post_value, Nega_value = Triggered_Procedure(DG,Lay_Candidaite_set)
                    Sum_P += Post_value
                    Sum_N += Nega_value
                
                if Sum_N/Sum_P < c:
                    Lay_i_Seed.append(Candidate_Set[0])
                del Med_Seed_set, Candidate_Set[0]
                 
            Seed_set.append(Lay_i_Seed)
        
        MedR = []
        for g in range(400):    
            Posi_value, Nega_value = Triggered_Procedure(DG, Seed_set)
            MedR.append(Posi_value)
    
        print("q", b, "The number of positive value Ave", round(sum(MedR)/400, 3))
    end = time.perf_counter()
    print('Running time: %s Seconds'%(end-start))