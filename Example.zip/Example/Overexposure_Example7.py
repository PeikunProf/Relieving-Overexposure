# -*- coding: utf-8 -*-
"""
@author: PeiKun

"""

import networkx
import time
import copy
import random
import math


def Triggered_Procedure(GD, Seed_Set):   
    This_Seed_set = copy.deepcopy(Seed_Set)
    All_Activate_nodes = copy.deepcopy(Seed_Set)

    while len(This_Seed_set) > 0: 
        
        New_seed_set = []
        for t in This_Seed_set:
            Fathe_set = list(GD.successors(t))
            for j in Fathe_set:
                if GD[t][j]['weight'] > random.random():
                    New_seed_set.append(j)
        All_Activate_nodes.extend(New_seed_set)    
        This_Seed_set = copy.deepcopy(New_seed_set)        
        
    return len(set(All_Activate_nodes))
      


# main function    
if __name__ == '__main__':
    start = time.perf_counter()
    
    #import links with influence probability and similarity
    f = open("Example.txt")       
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1], weight = float(split_row[2]))
    
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    print("The number of nodes", G.number_of_nodes())
    
    Delta = 0.5
    Epsio = 0.01
    Gamma = 1 + 4 * (math.exp(1) -2) * (1 + Epsio) * math.log(2/Delta) / Epsio ** 2
    
    All_node = DG.number_of_nodes()
    Seed_set =['2']
    Sum = 0
    Nn = 0
    while Sum < Gamma: 
        value = Triggered_Procedure(DG, Seed_set)
        Sum += value/All_node
        Nn += 1

    print("The number of experiment runs", Nn)
    end = time.perf_counter()
    print('Running time: %s Seconds'%(end-start))