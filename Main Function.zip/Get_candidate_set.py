# -*- coding: utf-8 -*-
"""
Get Candidate set
@author: PeiKun
"""

__all__ = ['Get_Candidate_procedure']
    

def Get_Candidate_procedure(CG):
    #Remove the effect of the seed nodes
    Non_Can_Nodes = []
    for j in CG.nodes():
        if CG.out_degree(j) < 2:
            Non_Can_Nodes.append(j)
    Possible_Nodes = list(set(CG.nodes()).difference(Non_Can_Nodes))
    del Non_Can_Nodes
    print("The", len(Possible_Nodes))
    
    Direct_influence = {}
    for i in Possible_Nodes:
        Direct_influence[i] = 0
        for ci in list( CG.successors(i)):
            Direct_influence[i] += CG[i][ci]['weight']
    print("The number", len(Direct_influence))
    
    
    Candidate_set = []
    while len(Direct_influence) > 0:
        Can_node = max(Direct_influence, key=Direct_influence.get)     #Get max value
        Candidate_set.append(Can_node)
        
        #Update the direct influence
        Del_nodes = []
        Del_nodes.append(Can_node)
        first_lay = list(CG.successors(Can_node))
        Del_nodes.extend(first_lay)
        Del_node = list(set(Del_nodes))
        del first_lay
        
        Effect_node = []
        for dn in Del_node:
            pfirst_lay = list(CG.predecessors(dn))
            Effect_node.extend(pfirst_lay)
        
        Del_influence_Nodes = list(set(Direct_influence.keys()).intersection(set(Del_node)))
        for j in Del_influence_Nodes:
            del Direct_influence[j]
            
        Effect_node = list(set(Effect_node).difference(set(Del_node)))
        CG.remove_nodes_from(Del_node)
        del Del_node
        #print("The number of delete nodes", len(Direct_influence) )
        
        True_Effect = list(set(Effect_node).intersection(set(Direct_influence.keys())))
        for cf in True_Effect:
            Direct_influence[cf] = 0
            for cj in list(CG.successors(cf)):
                Direct_influence[cf] += CG[cf][cj]['weight']
        del Effect_node
        
    return Candidate_set
 