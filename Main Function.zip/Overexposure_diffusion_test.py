# -*- coding: utf-8 -*-
"""
@author: PeiKun
"""

from Multi_Diffusion_procedure import Triggered_Procedure
from Get_candidate_set import Get_Candidate_procedure
import networkx
import time
import copy


    
def S_attention_clime(DG, Candidate_Set, b): 
    
    c = 0.01          # Parameter, Has been determined
    k = 4              # Triggered stage 
    Per = [0.125,0.125,0.25,0.5]  #Post; Pre; Equal    
    Seed_set = []
    for i in range(k):
        Lay_i_Seed = []
        b_new = int(b * Per[i])
        while len(Lay_i_Seed) < b_new and len(Candidate_Set) > 0:
            Med_Seed_set = copy.deepcopy(Seed_set)
            Med_Candidate = copy.deepcopy(Lay_i_Seed)
            Med_Candidate.append(Candidate_Set[0])
            Med_Seed_set.append(Med_Candidate)
            del Med_Candidate
            
            
            Sum_P = 0
            Sum_N = 0
            for j in range(400):
                Lay_Candidaite_set = copy.deepcopy(Med_Seed_set)
                Post_value, Nega_value = Triggered_Procedure(DG,Lay_Candidaite_set)
                Sum_P += Post_value
                Sum_N += Nega_value
                    
            if Sum_N/Sum_P < c:
                Lay_i_Seed.append(Candidate_Set[0])
            del Candidate_Set[0], Med_Seed_set 
        Seed_set.append(Lay_i_Seed)
        print("循环次数",i)
        
    Sum_P = 0
    for i in range(400):
         Post_value, Nega_value = Triggered_Procedure(DG, Seed_set)
         Sum_P += Post_value
    
    return Sum_P/400
        

# main function    
if __name__ == '__main__':
    start = time.perf_counter()
    #import links with influence probability and similarity
    f = open("Delicious_Pro_Sim.txt")  #Dataset: Douban, Delicious, Gemsec-Ro, Gnutella 
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1], weight = float(split_row[2]), Similarity = float(split_row[3]))
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    print("The number of nodes", G.number_of_nodes())
    
    #Get Candidate set
    CG = copy.deepcopy(DG)
    Candidate_Set = Get_Candidate_procedure(CG)        
    print("The number of Candidate", len(Candidate_Set))
    
    B_set = [40,80,120,160,200,240,280,320]
    for b in B_set:
        Result_New = S_attention_clime(DG,Candidate_Set,b)
        print("The number of positive value Ave", Result_New)
    
    end = time.perf_counter()
    print('Running time: %s Seconds'%(end-end))