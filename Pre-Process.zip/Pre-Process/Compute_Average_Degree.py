# -*- coding: utf-8 -*-
"""
Computer the average degree

@author: Peikun Ni
"""

import networkx
import copy


# main function    
if __name__ == '__main__':
     
    f = open("Gnutella.txt")       
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1])
          
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    print("The nodes", DG.number_of_nodes(), "The number of edges", DG.number_of_edges())
    print("The average degree", 2*DG.number_of_edges()/ DG.number_of_nodes())
        
  