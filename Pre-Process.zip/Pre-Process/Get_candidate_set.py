# -*- coding: utf-8 -*-

import networkx
import copy
import time

def writeTxt(dataList, fileName):  
    f = open(fileName, 'a')
    for i in dataList:
        f.write(str(i))
        f.write(' ')
    f.write('\n')


# main function    
if __name__ == '__main__':
    start = time.perf_counter()
    
    #import links with influence probability and similarity
    f = open("Delicious_Pro_Sim.txt")       
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1], weight = float(split_row[2]), Similarity = float(split_row[3]))
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    print("The number of nodes", G.number_of_nodes())

    Non_Can_Nodes = []
    for j in DG.nodes():
        if DG.out_degree(j) < 1:
            Non_Can_Nodes.append(j)
    Possible_Nodes = list(set(DG.nodes()).difference(Non_Can_Nodes))
    del Non_Can_Nodes
    print("The", len(Possible_Nodes))
    
    
    Direct_influence = {}
    for i in Possible_Nodes:
        Direct_influence[i] = 0
        for ci in list(DG.successors(i) ):
            Direct_influence[i] += DG[i][ci]['weight']
    print("The number", len(Direct_influence))
    

    Candidate_set = []
    while len(Direct_influence) > 0:
        Can_node = max(Direct_influence, key=Direct_influence.get)     #Get max value
        Candidate_set.append(Can_node)
        
        #Update the direct influence
        Del_nodes = []
        Del_nodes.append(Can_node)
        first_lay = list(DG.successors(Can_node))
        Del_nodes.extend(first_lay)
        Del_node = list(set(Del_nodes))
        del first_lay
        
        Effect_node = []
        for dn in Del_node:
            pfirst_lay = list(DG.predecessors(dn))
            Effect_node.extend(pfirst_lay)
        
        Del_influence_Nodes = list(set(Direct_influence.keys()).intersection(set(Del_node)))
        for j in Del_influence_Nodes:
            del Direct_influence[j]
            
        Effect_node = list(set(Effect_node).difference(set(Del_node)))
        DG.remove_nodes_from(Del_node)
        del Del_node
        #print("The number of delete nodes", len(Direct_influence) )
        
        True_Effect = list(set(Effect_node).intersection(set(Direct_influence.keys())))
        for cf in True_Effect:
            Direct_influence[cf] = 0
            for cj in list(DG.successors(cf)):
                Direct_influence[cf] += DG[cf][cj]['weight']
        del Effect_node
        
    writeTxt(Candidate_set, "Delicious_candidate.txt")
    
    print("The time")