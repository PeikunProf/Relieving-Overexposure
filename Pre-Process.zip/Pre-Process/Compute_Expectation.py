# -*- coding: utf-8 -*-
"""

@author: Peikun Ni
"""

import networkx
import copy
import random

def writeTxt(dataList, fileName):  
    f = open(fileName, 'a')
    for ele in dataList:
        f.write(str(ele))
        f.write(' ')
    f.write('\n')

# main function    
if __name__ == '__main__':
     
    f = open("Douban_Pro_Sim.txt")       
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1])
          
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    

    for i in DG.nodes():
        Med = []
        for j in range(len(list(DG.predecessors(i)))):
            Med.append(round(random.random(), 3))
        if len(Med) > 0:    
            writeTxt([i, max(Med)], "Douban_expectation.txt")
            print("The indgree", max(Med))
        else:
            writeTxt([i, round(random.random(), 3)], "Douban_expectation.txt")
        
    
    print("The average degree", 2*DG.number_of_edges()/ DG.number_of_nodes())
        
  