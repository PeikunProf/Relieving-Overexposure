
import random

def writeTxt(dataList, fileName):  #output data
    f = open(fileName, 'a')
    for i in dataList:
        f.write(str(i))
        f.write(' ')
    f.write('\n')
    
# main function    
if __name__ == '__main__':
    #import data
    f = open("Delicious_Links.txt")
    data = f.read()
    rows = data.split('\n')
    i = 1
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            print("第",i,"条边")
            edges_fl = [split_row[0], split_row[1]] 
            edges_fl.extend(random.sample([0.15,0.1,0.05],1))
            i += 1
            writeTxt(edges_fl,"Delicious_probability.txt")
    
    print('Running time: %s Seconds')