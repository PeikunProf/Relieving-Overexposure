# -*- coding: utf-8 -*-
"""
Compute the similarity between individuals

@author: PeiKun
"""

import networkx
import copy

def writeTxt(dataList, fileName):  
    f = open(fileName, 'a')
    for ele in dataList:
        f.write(str(ele))
        f.write(' ')
    f.write('\n')
    
 
# main function    
if __name__ == '__main__':
    
    f = open("Delicious_probability.txt")       
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1], weight = float(split_row[2]) )
          
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    print("The number of nodes", G.number_of_nodes())
    
    i = 1
    for e in DG.edges():
        Neigh_e0 = list(DG.predecessors(e[0]))
        Neigh_e0.extend(list(DG.successors(e[0])) )
        Neigh_e0 = list(set(Neigh_e0))
        
        Neigh_e1 = list(DG.predecessors(e[1]))
        Neigh_e1.extend(list(DG.successors(e[1])) )
        Neigh_e1 = list(set(Neigh_e1))
        
        Uni_e = len( set(Neigh_e0).intersection(set( Neigh_e1)) )
        
        Sim = 1 - Uni_e / min(len(Neigh_e1), len(Neigh_e0))
        
        del Neigh_e0, Neigh_e1, Uni_e
        writeTxt([e[0], e[1], DG[e[0]][e[1]]['weight'], round(Sim,3)],"Delicious_Pro_Sim.txt")
        
        print("Number of edges processed", i)
        i += 1
        
    
    print('Running time: %s Seconds')