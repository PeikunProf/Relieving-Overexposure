# -*- coding: utf-8 -*-
"""
@author: PeiKun

"""

from Multi_Diffusion_procedure import Triggered_Procedure
import networkx
import time
import copy
import random


def writeTxt(dataList, fileName):  
    f = open(fileName, 'a')
    f.write(str(dataList))
    f.write('\n')
      

# main function    
if __name__ == '__main__':
    start = time.perf_counter()
    #import links with influence probability and similarity
    f = open("Delicious_Pro_Sim.txt") 
    #f = open("Douban_Pro_Sim.txt") 
    #f = open("Gnutella_Pro_Sim.txt")
    #f = open("Gemsec_Pro_Sim.txt")
        
    data = f.read()
    rows = data.split('\n')
    edges_set = []
    G = networkx.DiGraph()
    for row in rows:
        split_row = row.split()
        if len(split_row) > 1:
            G.add_edge(split_row[0], split_row[1], weight = float(split_row[2]), Similarity = float(split_row[3]))
    
    #change to directed graph
    if not G.is_directed():
        DG = networkx.DiGraph(G)
    else:
        DG = copy.deepcopy(G)
    print("The number of nodes", G.number_of_nodes())
    
    Per = [0.125,0.125,0.25,0.5]
    c = 0.01           # Parameter, Has been determined
    k = 4             # Triggered stage
    b_set = 320
    
    Candidate_Set = list(DG.nodes())
    Seed_set_Can = random.sample(Candidate_Set, b_set+10)
    
    Seed_set = []
    for i in range(k):
        B_new = int(b_set*Per[i])
        Lay_i_Seed = Seed_set_Can[0:B_new]
        del Seed_set_Can[0:B_new]
        Seed_set.append(Lay_i_Seed)  
        del Lay_i_Seed
    
    Sum_P = 0
    for j in range(1000):
        Seed_set_C = copy.deepcopy(Seed_set)
        Posi_value, Nega_value = Triggered_Procedure(DG, Seed_set_C)
        Sum_P += Posi_value
        
        if (j+1)%100 == 0:
            print(j+1, "The value", Sum_P/(j+1))
        
    end = time.perf_counter()
    print('Running time: %s Seconds'%(end-start))