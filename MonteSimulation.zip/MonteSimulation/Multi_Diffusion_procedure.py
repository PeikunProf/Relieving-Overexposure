# -*- coding: utf-8 -*-
"""
Peikun Ni
This algorithm is for Delicious, Epinions
"""
import copy
import math
import random


__all__ = ['Triggered_Procedure']

def Triggered_Procedure(GD, Seed_Ind_Set):   #'Seed_Ind_Set' is set, the subset is list 

    Tg = 3            #Triggering interval
    Expection_set = {}
    for i in GD.nodes():
        Expection_set[i] = 0
    
    Initial_seed = Seed_Ind_Set[0]
    Already_Propa_Inds = copy.deepcopy(Initial_seed)  
    New_Propa_Inds = copy.deepcopy(Initial_seed) 
    Silent_set = []
    
    min_step = Tg * len(Seed_Ind_Set)
    t = 1                         
    while len(New_Propa_Inds) > 0 or t < min_step + 1: 
        
        This_actived_P, This_active_silent, New_Expection_set = diffuse_one_round(GD, New_Propa_Inds, Already_Propa_Inds, Silent_set, Expection_set)
        Silent_set.extend(This_active_silent)
        Expection_set = copy.deepcopy(New_Expection_set)
        
        for k in Expection_set.keys():
            Expection_set[k] = Expection_set[k] / math.log10(10 + t)
        t += 1
       
        if (t-1) % Tg == 0 and t <= min_step:
            ss_index = int((t-1)/Tg)
            Seed2 = Seed_Ind_Set[ss_index]
            Silent_set = list(set(Silent_set).difference(Seed2))
            Med_2 = list(set(Seed2).difference(set(Already_Propa_Inds)) )
            New_Propa_Inds = list(set(This_actived_P).union(set(Med_2)))
        else:
            New_Propa_Inds = copy.deepcopy(This_actived_P)
        Already_Propa_Inds.extend(New_Propa_Inds)
        
        del This_active_silent, This_actived_P, New_Expection_set
        
    
    Num_Propa_Inds = len(set(Already_Propa_Inds))
    Num_Silent_Inds = len(set(Silent_set))
    
    return Num_Propa_Inds, Num_Silent_Inds

def diffuse_one_round(CG, New_Propa_set, Already_Propa_set, Silent_set, Expect_set):   #Return This_active_Prop, This_active_silent and Expection_set
    Au = 0.5        #The actual utility of the product, has been determined
    
    All_act_nodes = list(set(Already_Propa_set).union(set(Silent_set)))
    Layer_Propa_Nodes = []
    Layer_Silent_Nodes = []
    
    for p in New_Propa_set:
        Un_Child_a = list( set(CG.successors(p)).difference(set(All_act_nodes) ))
        #First Update the expectation, and then try to activate.
        for q in Un_Child_a:
            Delta = (1 - Expect_set[q]) * (Au - Expect_set[p]) / (1 + CG[p][q]['Similarity'] ** 2) 
            Expect_set[q] = 1 - (1 - Expect_set[q]) * (1 - Delta)
            del Delta
    
    #Information diffusion
    for a in New_Propa_set:
        Un_Child_a = list( set(CG.successors(a)).difference(set(All_act_nodes) ))
        #First Update the expectation, and then try to activate.
        for d in Un_Child_a:
            if random.random() < CG[a][d]['weight']:
                if Expect_set[d] < Au:
                    Layer_Propa_Nodes.append(d)
                else:
                    Layer_Silent_Nodes.append(d)
                All_act_nodes.append(d)
                         
    Layer_Propa_Nodes = list(set(Layer_Propa_Nodes).difference(set(Layer_Silent_Nodes))) 
    Layer_Silent_Nodes = list(set(Layer_Silent_Nodes))
            
    return Layer_Propa_Nodes, Layer_Silent_Nodes, Expect_set
